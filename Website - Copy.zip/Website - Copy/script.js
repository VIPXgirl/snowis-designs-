const revealSelector = [
  'main > section',
  '.about-image-wrapper',
  '.about-details',
  '.gallery-card',
  '.work-card',
  '.pricing-card',
  '.menu-item',
  '.faq-item',
  '.contact-info',
  '.contact-form',
  'footer',
  '.page-nav',
  '.gallery-page-grid > article',
  '.design-services-page-grid > article'
].join(', ');

const revealElements = Array.from(document.querySelectorAll(revealSelector));

const menuOpenButton = document.getElementById('menu-open-button');
const primaryNavigation = document.getElementById('primary-navigation');

function setMobileMenuOpen(isOpen) {
  document.body.classList.toggle('show-mobile-menu', isOpen);
  menuOpenButton?.setAttribute('aria-expanded', String(isOpen));
  menuOpenButton?.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  if (isOpen) {
    primaryNavigation?.querySelector('.nav-link')?.focus();
  } else if (primaryNavigation?.contains(document.activeElement)) {
    menuOpenButton?.focus();
  }
}

menuOpenButton?.addEventListener('click', () => {
  setMobileMenuOpen(!document.body.classList.contains('show-mobile-menu'));
});
document.querySelector('header')?.addEventListener('click', (event) => {
  if (event.target === event.currentTarget && document.body.classList.contains('show-mobile-menu')) {
    setMobileMenuOpen(false);
  }
});
primaryNavigation?.addEventListener('click', (event) => {
  if (event.target.closest('a')) setMobileMenuOpen(false);
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') setMobileMenuOpen(false);
});
window.addEventListener('resize', () => {
  if (window.innerWidth > 900) setMobileMenuOpen(false);
});

revealElements.forEach((element, index) => {
  element.classList.add('reveal-on-scroll');
  element.style.transitionDelay = `${index * 35}ms`;
});

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.01 }
);

revealElements.forEach((element) => revealObserver.observe(element));

const serviceGalleries = {
  profile: ['✨', '🎨', '💫', '❄️', '🌌', '🖼️', '💙', '🎭', '🌟', '🪄', '🎀', '✨'],
  banners: ['🏞️', '🌊', '✨', '🌙', '🎨', '🖌️', '🌃', '🔥', '🌠', '💎', '🌈', '🖼️'],
  youtube: ['🎵', '📈', '🎬', '✨', '🔥', '💙', '🎧', '📺', '🌟', '🕶️', '🚀', '🎤'],
  emojis: ['😊', '😄', '🌟', '💖', '✨', '🎉', '🤍', '😎', '💫', '🎀', '🌸', '🎁'],
  stickers: ['✨', '🧩', '🌈', '🎀', '💫', '🌷', '🦋', '🪷', '🌼', '💠', '🩷', '🌙'],
  branding: ['💼', '🚀', '⭐', '💫', '📦', '🎨', '🧠', '💡', '🔥', '🌌', '💎', '🪄']
};

const minimumSlides = 3;
Object.keys(serviceGalleries).forEach((key) => {
  while (serviceGalleries[key].length < minimumSlides) {
    serviceGalleries[key].push(serviceGalleries[key][0] || '✨');
  }
});

const profileGalleryTriggers = document.querySelectorAll('.profile-gallery-trigger');
const profileLightbox = document.getElementById('profile-lightbox');
const profileLightboxGallery = document.getElementById('profile-lightbox-gallery');
const profileLightboxClose = document.querySelector('.profile-lightbox-close');
const profileLightboxArrowLeft = document.querySelector('.profile-lightbox-arrow-left');
const profileLightboxArrowRight = document.querySelector('.profile-lightbox-arrow-right');

if (profileLightbox && profileLightboxGallery && profileGalleryTriggers.length) {
  let activeGallerySlides = [];
  let activeSlideIndex = 0;

  function renderSlides() {
    if (!activeGallerySlides.length) {
      profileLightboxGallery.innerHTML = '';
      profileLightboxGallery.style.transform = 'translateX(0px)';
      return;
    }

    profileLightboxGallery.innerHTML = activeGallerySlides
      .map((emoji, index) => {
        const activeClass = index === activeSlideIndex ? 'is-active' : '';
        return `<div class="emoji-gallery-slide ${activeClass}">${emoji}</div>`;
      })
      .join('');

    const firstSlide = profileLightboxGallery.querySelector('.emoji-gallery-slide');
    const slideWidth = firstSlide ? firstSlide.getBoundingClientRect().width : 0;
    const gap = 18;
    profileLightboxGallery.style.transform = `translateX(-${activeSlideIndex * (slideWidth + gap)}px)`;
  }

  function closeProfileGallery() {
    profileLightbox.classList.remove('is-open');
    profileLightbox.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  function openProfileGallery(galleryKey) {
    const slides = serviceGalleries[galleryKey] || serviceGalleries.profile;
    activeGallerySlides = slides;
    activeSlideIndex = 0;
    renderSlides();
    profileLightbox.classList.add('is-open');
    profileLightbox.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function showPreviousSlide() {
    if (!activeGallerySlides.length) return;
    activeSlideIndex = (activeSlideIndex - 1 + activeGallerySlides.length) % activeGallerySlides.length;
    renderSlides();
  }

  function showNextSlide() {
    if (!activeGallerySlides.length) return;
    activeSlideIndex = (activeSlideIndex + 1) % activeGallerySlides.length;
    renderSlides();
  }

  profileGalleryTriggers.forEach((trigger) => {
    trigger.addEventListener('click', () => {
      openProfileGallery(trigger.dataset.gallery || 'profile');
    });
  });

  profileLightboxClose?.addEventListener('click', closeProfileGallery);
  profileLightboxArrowLeft?.addEventListener('click', showPreviousSlide);
  profileLightboxArrowRight?.addEventListener('click', showNextSlide);

  profileLightbox.addEventListener('click', (event) => {
    if (event.target === profileLightbox) {
      closeProfileGallery();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (!profileLightbox.classList.contains('is-open')) return;

    if (event.key === 'Escape') {
      closeProfileGallery();
    }

    if (event.key === 'ArrowLeft') {
      showPreviousSlide();
    }

    if (event.key === 'ArrowRight') {
      showNextSlide();
    }
  });
}
