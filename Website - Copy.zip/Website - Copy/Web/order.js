const serviceSelect = document.getElementById("order-service");
const orderForm = document.getElementById("order-form");
const orderFeedback = document.getElementById("order-feedback");
const orderPrice = document.getElementById("order-price");
const fileInput = document.getElementById("order-files");
const fileDropzone = document.getElementById("order-file-dropzone");
const fileList = document.getElementById("order-file-list");
const orderPreview = document.getElementById("order-preview");
const editOrderButton = document.getElementById("edit-order");
const saveOrderPdfButton = document.getElementById("save-order-pdf");
const sendOrderRequestButton = document.getElementById("send-order-request");
const orderPreviewStatus = document.querySelector(".order-preview-status");
const orderPreviewIntro = document.getElementById("order-preview-intro");
const orderRecipient = "snowihouse3@gmail.com";
const orderEmailEndpoint = `https://formsubmit.co/ajax/${orderRecipient}`;
const referenceFiles = [];
let requestPdfBlob = null;
let requestPdfFilename = "";
let requestPdfAutoDownloaded = false;
let activeRequestFormData = null;
let activeRequestService = null;
const unavailableCategories = new Set([
  "🤍 Icons ❄️",
  "🤍 Logos ❄️",
  "🤍 Wallpapers ❄️",
  "🤍 Emojis ❄️",
  "🤍 Banners ❄️",
  "🤍 Sticker bundles ❄️",
  "🤍 Emoji bundles ❄️"
]);
const fallbackServices = [
  { category: "Profile pictures", name: "Simple PFP / avatar", price: "10–15€" },
  { category: "Profile pictures", name: "Detailed PFP", price: "18–25€" },
  { category: "Character art", name: "Custom character bust", price: "12–18€" },
  { category: "Character art", name: "Custom character half body", price: "18–25€" },
  { category: "Character art", name: "Full body character", price: "25–35€" },
  { category: "Stickers", name: "Simple sticker", price: "4€" }
];

function readStoredData(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "null");
    const publishedData = key === "adminPageData" ? window.SNOWI_PUBLISHED_DATA : null;
    return value ?? publishedData ?? fallback;
  } catch (error) {
    return fallback;
  }
}

function getAvailableServices() {
  const data = readStoredData("adminPageData", {});
  const categories = Array.isArray(data.pricingCategories)
    ? data.pricingCategories.filter((category) => category && !unavailableCategories.has(category.title))
    : [];
  const savedServices = categories.flatMap((category) => (category.items || [])
    .filter((item) => item && item.name)
    .map((item) => ({ category: category.title || "Design service", name: item.name, price: item.price || "Ask for a quote" })));
  return savedServices.length ? savedServices : fallbackServices;
}

const availableServices = getAvailableServices();
availableServices.forEach((service, index) => {
  let group = serviceSelect.querySelector(`optgroup[data-category-index="${index}"]`);
  const previousService = availableServices[index - 1];
  const categoryChanged = !previousService || previousService.category !== service.category;
  if (categoryChanged) {
    group = document.createElement("optgroup");
    group.label = service.category;
    group.dataset.categoryIndex = String(index);
    serviceSelect.appendChild(group);
  } else {
    group = serviceSelect.lastElementChild;
  }
  const option = document.createElement("option");
  option.value = String(index);
  option.textContent = `${service.name} · ${service.price}`;
  option.dataset.price = service.price;
  group.appendChild(option);
});

function selectedService() {
  if (serviceSelect.value === "") return null;
  return availableServices[Number(serviceSelect.value)] || null;
}

function updateOrderState() {
  const service = selectedService();
  orderPrice.textContent = service
    ? `Listed price: ${service.price}. Final quote confirmed after discussing your idea.`
    : "Listed price appears when you choose a service.";
  if (orderForm.checkValidity()) {
    orderFeedback.classList.remove("is-error");
    const attachmentNote = referenceFiles.length
      ? ` Your ${referenceFiles.length} selected reference file${referenceFiles.length === 1 ? "" : "s"} will be attached to the request email.`
      : "";
    orderFeedback.textContent = `Your request is ready to review.${attachmentNote}`;
  } else {
    orderFeedback.textContent = orderFeedback.classList.contains("is-error")
      ? "Please fill in all required fields before sending your order."
      : "";
  }
}

function formatFileSize(size) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function addReferenceFiles(files) {
  Array.from(files).forEach((file) => {
    if (!file || referenceFiles.some((entry) => entry.file.name === file.name && entry.file.size === file.size && entry.file.lastModified === file.lastModified)) return;
    referenceFiles.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      file,
      previewUrl: file.type.startsWith("image/") ? URL.createObjectURL(file) : ""
    });
  });
  renderReferenceFiles();
  updateOrderState();
}

function renderReferenceFiles() {
  fileList.replaceChildren();
  referenceFiles.forEach((entry) => {
    const item = document.createElement("div");
    item.className = "order-file-item";

    if (entry.previewUrl) {
      const image = document.createElement("img");
      image.className = "order-file-thumbnail";
      image.src = entry.previewUrl;
      image.alt = `Preview of ${entry.file.name}`;
      item.appendChild(image);
    } else {
      const badge = document.createElement("span");
      badge.className = "order-file-badge";
      badge.textContent = "FILE";
      item.appendChild(badge);
    }

    const details = document.createElement("span");
    details.className = "order-file-details";
    const name = document.createElement("strong");
    name.textContent = entry.file.name;
    const size = document.createElement("small");
    size.textContent = formatFileSize(entry.file.size);
    details.append(name, size);

    const removeButton = document.createElement("button");
    removeButton.className = "order-file-remove";
    removeButton.type = "button";
    removeButton.textContent = "Remove";
    removeButton.setAttribute("aria-label", `Remove ${entry.file.name}`);
    removeButton.addEventListener("click", () => {
      const index = referenceFiles.findIndex((file) => file.id === entry.id);
      if (index === -1) return;
      if (entry.previewUrl) URL.revokeObjectURL(entry.previewUrl);
      referenceFiles.splice(index, 1);
      renderReferenceFiles();
      updateOrderState();
    });

    item.append(details, removeButton);
    fileList.appendChild(item);
  });
}

function clipboardFiles(clipboardData) {
  const files = Array.from(clipboardData.files || []);
  if (files.length) return files;
  Array.from(clipboardData.items || []).forEach((item) => {
    if (item.kind !== "file") return;
    const file = item.getAsFile();
    if (file) files.push(file);
  });
  return files;
}

function populateRequestDocument(formData, service) {
  const subject = `Commission request from ${String(formData.get("name") || "new customer").trim()}`;
  document.getElementById("preview-subject").textContent = subject;
  document.getElementById("preview-client-name").textContent = String(formData.get("name") || "Not added");
  const clientEmail = String(formData.get("email") || "");
  const clientEmailLink = document.getElementById("preview-client-email");
  clientEmailLink.textContent = clientEmail;
  clientEmailLink.href = `mailto:${clientEmail}`;
  document.getElementById("preview-service").textContent = service ? service.name : "Not selected";
  document.getElementById("preview-order-meta").textContent = `${formData.get("quantity") || "1"} item · ${service ? service.price : "Price to be confirmed"} · ${formData.get("deadline") || "Flexible"}`;
  document.getElementById("preview-idea").textContent = String(formData.get("idea") || "Not provided");
  const previewFiles = document.getElementById("preview-files");
  previewFiles.replaceChildren();
  if (referenceFiles.length) {
    referenceFiles.forEach(({ file }) => {
      const item = document.createElement("li");
      item.textContent = file.name;
      previewFiles.appendChild(item);
    });
  } else {
    const item = document.createElement("li");
    item.textContent = "No reference files attached";
    previewFiles.appendChild(item);
  }
}

function pdfText(value) {
  const winAnsiSpecials = {
    0x20ac: 0x80, 0x201a: 0x82, 0x0192: 0x83, 0x201e: 0x84, 0x2026: 0x85,
    0x2020: 0x86, 0x2021: 0x87, 0x02c6: 0x88, 0x2030: 0x89, 0x0160: 0x8a,
    0x2039: 0x8b, 0x0152: 0x8c, 0x017d: 0x8e, 0x2018: 0x91, 0x2019: 0x92,
    0x201c: 0x93, 0x201d: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97,
    0x02dc: 0x98, 0x2122: 0x99, 0x0161: 0x9a, 0x203a: 0x9b, 0x0153: 0x9c,
    0x017e: 0x9e, 0x0178: 0x9f
  };
  const result = [];
  for (const character of String(value ?? "")) {
    const code = character.codePointAt(0);
    if (code === 10 || code === 13) {
      result.push(code);
    } else if (code <= 0x7e || (code >= 0xa0 && code <= 0xff)) {
      result.push(code);
    } else {
      result.push(winAnsiSpecials[code] || 0x3f);
    }
  }
  return `<${result.map((code) => code.toString(16).padStart(2, "0")).join("")}>`;
}

function wrapPdfText(value, maxCharacters) {
  const paragraphs = String(value || "Not provided").replace(/\r\n?/g, "\n").split("\n");
  const lines = [];
  paragraphs.forEach((paragraph) => {
    const words = paragraph.trim().split(/\s+/).filter(Boolean);
    if (!words.length) {
      lines.push("");
      return;
    }
    let line = "";
    words.forEach((word) => {
      if (word.length > maxCharacters) {
        if (line) lines.push(line);
        line = "";
        for (let index = 0; index < word.length; index += maxCharacters) {
          const part = word.slice(index, index + maxCharacters);
          if (part.length === maxCharacters) lines.push(part);
          else line = part;
        }
      } else if (!line) {
        line = word;
      } else if (`${line} ${word}`.length <= maxCharacters) {
        line += ` ${word}`;
      } else {
        lines.push(line);
        line = word;
      }
    });
    if (line) lines.push(line);
  });
  return lines.length ? lines : ["Not provided"];
}

function createRequestPdf(formData, service) {
  const pageWidth = 595;
  const pageHeight = 842;
  const left = 42;
  const contentWidth = pageWidth - left * 2;
  const pages = [];
  let page;
  let cursorY;

  function color(hex) {
    return hex.match(/[0-9a-f]{2}/gi).map((part) => (parseInt(part, 16) / 255).toFixed(3)).join(" ");
  }

  function addText(text, x, top, size, font = "F1", fill = "#172448") {
    page.push(`BT /${font} ${size} Tf ${color(fill)} rg 1 0 0 1 ${x.toFixed(2)} ${(pageHeight - top - size).toFixed(2)} Tm ${pdfText(text)} Tj ET`);
  }

  function addRect(x, top, width, height, fill, stroke) {
    const bottom = pageHeight - top - height;
    page.push(`${color(fill)} rg ${color(stroke)} RG 0.8 w ${x.toFixed(2)} ${bottom.toFixed(2)} ${width.toFixed(2)} ${height.toFixed(2)} re B`);
  }

  function addPage(isCover = false) {
    page = [];
    pages.push(page);
    if (isCover) {
      page.push(`${color("#111b3d")} rg 0 ${pageHeight - 142} ${pageWidth} 142 re f`);
      page.push(`${color("#85e4f7")} rg ${left} ${pageHeight - 46} 46 4 re f`);
      addText("SNOWI'S DESIGNS  /  COMMISSION REQUEST", left, 63, 9, "F2", "#aeeffc");
      addText("Your commission brief", left, 82, 25, "F2", "#ffffff");
      addText(`Prepared for ${formData.get("name") || "Customer"}`, left, 116, 10, "F1", "#e0e9ff");
      const dateText = new Intl.DateTimeFormat("en", { dateStyle: "medium" }).format(new Date());
      addText(`REQUEST COPY  |  ${dateText}`, pageWidth - left - 144, 64, 8, "F2", "#aeeffc");
      cursorY = 164;
    } else {
      page.push(`${color("#111b3d")} rg 0 ${pageHeight - 52} ${pageWidth} 52 re f`);
      page.push(`${color("#85e4f7")} rg ${left} ${pageHeight - 32} 34 3 re f`);
      addText("SNOWI'S DESIGNS  /  COMMISSION REQUEST", left, 20, 8, "F2", "#ffffff");
      addText(String(formData.get("name") || "Customer"), pageWidth - left - 120, 20, 8, "F1", "#aeeffc");
      cursorY = 76;
    }
  }

  function ensureSpace(height) {
    if (cursorY + height > pageHeight - 52) addPage();
  }

  function sectionHeading(title) {
    ensureSpace(34);
    page.push(`${color("#51bfd4")} rg ${left} ${pageHeight - cursorY - 19} 4 19 re f`);
    addText(title, left + 13, cursorY + 2, 10, "F2", "#172448");
    cursorY += 29;
  }

  function drawInfoCard(x, y, width, title, rows) {
    const preparedRows = rows.map(([label, value]) => ({
      label,
      lines: wrapPdfText(value || "Not provided", Math.max(18, Math.floor((width - 26) / 5.4)))
    }));
    const height = 34 + preparedRows.reduce((total, row) => total + 26 + Math.max(0, row.lines.length - 1) * 12, 0);
    addRect(x, y, width, height, "#f5f8fc", "#dce5ef");
    addText(title, x + 13, y + 12, 8, "F2", "#42617f");
    let rowY = y + 31;
    preparedRows.forEach((row) => {
      addText(row.label.toUpperCase(), x + 13, rowY, 6.5, "F2", "#66758b");
      row.lines.forEach((line, index) => addText(line, x + 13, rowY + 9 + index * 12, 9, "F1", "#172448"));
      rowY += 26 + Math.max(0, row.lines.length - 1) * 12;
    });
    return height;
  }

  function drawTextCard(lines) {
    let index = 0;
    while (index < lines.length) {
      const availableLines = Math.floor((pageHeight - 52 - cursorY - 28) / 14);
      if (availableLines < 1) {
        addPage();
        continue;
      }
      const chunk = lines.slice(index, index + availableLines);
      const height = chunk.length * 14 + 22;
      addRect(left, cursorY, contentWidth, height, "#f5f8fc", "#dce5ef");
      chunk.forEach((line, lineIndex) => addText(line, left + 14, cursorY + 12 + lineIndex * 14, 9, "F1", "#26344e"));
      cursorY += height + 8;
      index += chunk.length;
      if (index < lines.length) addPage();
    }
  }

  addPage(true);
  const gap = 14;
  const cardWidth = (contentWidth - gap) / 2;
  const cardTop = cursorY;
  const customerHeight = drawInfoCard(left, cardTop, cardWidth, "CLIENT", [
    ["Name", formData.get("name")],
    ["Email", formData.get("email")]
  ]);
  const serviceName = service ? service.name : "Not selected";
  const serviceCategory = service
    ? String(service.category || "Design service").replace(/[\u{1F300}-\u{1FAFF}\u2600-\u27BF]/gu, "").trim()
    : "Design service";
  const projectHeight = drawInfoCard(left + cardWidth + gap, cardTop, cardWidth, "PROJECT DETAILS", [
    ["Service", serviceName],
    ["Category", serviceCategory],
    ["Listed price", service ? service.price : "Price to be confirmed"],
    ["Quantity", formData.get("quantity") || "1"],
    ["Preferred timing", formData.get("deadline") || "Flexible"]
  ]);
  cursorY = cardTop + Math.max(customerHeight, projectHeight) + 23;

  sectionHeading("YOUR CREATIVE BRIEF");
  drawTextCard(wrapPdfText(formData.get("idea"), 96));

  sectionHeading("REFERENCE FILES");
  const fileNames = referenceFiles.length
    ? referenceFiles.map(({ file }) => `- ${file.name}`)
    : ["No reference files attached"];
  drawTextCard(fileNames.flatMap((fileName) => wrapPdfText(fileName, 96)));
  ensureSpace(35);
  addText("Original reference files are attached to the request email; this PDF lists their names.", left, cursorY + 2, 8, "F1", "#66758b");

  pages.forEach((commands, index) => {
    commands.push(`${color("#dce5ef")} RG 0.6 w ${left} 36 m ${pageWidth - left} 36 l S`);
    commands.push(`BT /F1 8 Tf ${color("#66758b")} rg 1 0 0 1 ${left} 22 Tm ${pdfText("SNOWI'S DESIGNS  |  COMMISSION REQUEST")} Tj ET`);
    commands.push(`BT /F1 8 Tf ${color("#66758b")} rg 1 0 0 1 ${pageWidth - left - 45} 22 Tm ${pdfText(`PAGE ${index + 1} OF ${pages.length}`)} Tj ET`);
  });

  const pageIds = pages.map((_, index) => 5 + index * 2);
  const objects = [];
  objects[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  objects[2] = `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pages.length} >>`;
  objects[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  objects[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
  pages.forEach((commands, index) => {
    const pageId = pageIds[index];
    const contentId = pageId + 1;
    const stream = commands.join("\n");
    objects[pageId] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>`;
    objects[contentId] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
  });

  let documentText = "%PDF-1.4\n";
  const offsets = [0];
  for (let id = 1; id < objects.length; id += 1) {
    offsets[id] = documentText.length;
    documentText += `${id} 0 obj\n${objects[id]}\nendobj\n`;
  }
  const xrefOffset = documentText.length;
  documentText += `xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for (let id = 1; id < objects.length; id += 1) {
    documentText += `${String(offsets[id]).padStart(10, "0")} 00000 n \n`;
  }
  documentText += `trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  return new Blob([documentText], { type: "application/pdf" });
}

function downloadRequestPdf() {
  if (!requestPdfBlob) return;
  const downloadUrl = URL.createObjectURL(requestPdfBlob);
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = requestPdfFilename;
  link.hidden = true;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(downloadUrl), 1000);
}

async function sendCommissionRequest(formData, service) {
  const fields = {
    _subject: `Commission request from ${String(formData.get("name") || "new customer").trim()}`,
    _replyto: String(formData.get("email") || "").trim(),
    _template: "table",
    _honey: "",
    customer_name: String(formData.get("name") || "").trim(),
    customer_email: String(formData.get("email") || "").trim(),
    service: service?.name || "Not selected",
    category: service?.category || "Design service",
    listed_price: service?.price || "Price to be confirmed",
    quantity: String(formData.get("quantity") || "1"),
    preferred_timing: String(formData.get("deadline") || "Flexible"),
    creative_brief: String(formData.get("idea") || "").trim(),
    reference_files: referenceFiles.length
      ? referenceFiles.map(({ file }) => file.name.replace(/[\r\n]/g, " ")).join(", ")
      : "None"
  };
  sendOrderRequestButton.disabled = true;
  sendOrderRequestButton.textContent = "Sending…";
  orderPreviewIntro.classList.remove("is-error");
  orderPreviewIntro.textContent = "Sending your request…";
  sendOrderRequestButton.hidden = true;

  try {
    if (!requestPdfBlob) {
      requestPdfBlob = createRequestPdf(formData, service);
      const customerSlug = String(formData.get("name") || "customer")
        .normalize("NFKD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "") || "customer";
      const dateSlug = new Date().toISOString().slice(0, 10);
      requestPdfFilename = `commission-request-${customerSlug}-${dateSlug}.pdf`;
      saveOrderPdfButton.textContent = "Download request PDF";
      saveOrderPdfButton.hidden = false;
      if (!requestPdfAutoDownloaded) {
        downloadRequestPdf();
        requestPdfAutoDownloaded = true;
      }
    }

    const emailData = new FormData();
    Object.entries(fields).forEach(([name, value]) => emailData.append(name, value));
    emailData.append("attachment", requestPdfBlob, requestPdfFilename);
    referenceFiles.forEach(({ file }) => {
      emailData.append("attachment", file, file.name);
    });
    const response = await fetch(orderEmailEndpoint, {
      method: "POST",
      headers: { Accept: "application/json" },
      body: emailData
    });
    const result = await response.json();
    if (!response.ok || (result.success !== true && result.success !== "true")) {
      throw new Error(result.message || `Request email failed with status ${response.status}.`);
    }

    orderPreviewStatus.textContent = "SENT";
    const sentItems = referenceFiles.length
      ? `Your request, PDF, and ${referenceFiles.length} reference file${referenceFiles.length === 1 ? "" : "s"} were sent.`
      : "Your request and PDF were sent.";
    const customerName = String(formData.get("name") || "there").trim();
    const customerEmail = String(formData.get("email") || "").trim();
    document.getElementById("order-preview-title").textContent = "Thank you for your request!";
    orderPreviewIntro.textContent = `${sentItems} Thank you, ${customerName}! Please wait for a reply at ${customerEmail}. Check your inbox and spam folder. A local PDF copy is ready to download.`;
    editOrderButton.hidden = true;
    sendOrderRequestButton.hidden = true;
  } catch (error) {
    console.error("Commission request email could not be sent.", error);
    orderPreviewStatus.textContent = "NOT SENT";
    const failureReason = window.location.protocol === "file:"
      ? "This page is open as a local file. Browsers may block its email request; open the site through an HTTP/HTTPS web server or deploy it first."
      : error instanceof Error && error.message
        ? error.message
        : "The email service did not return a readable error.";
    orderPreviewIntro.textContent = `${failureReason} If this is the first submission, approve FormSubmit's activation email for ${orderRecipient}.`;
    orderPreviewIntro.classList.add("is-error");
    sendOrderRequestButton.disabled = false;
    sendOrderRequestButton.textContent = "Try again";
    sendOrderRequestButton.hidden = false;
    editOrderButton.hidden = false;
    saveOrderPdfButton.hidden = !requestPdfBlob;
  }
}

orderForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!orderForm.reportValidity()) {
    orderFeedback.classList.add("is-error");
    orderFeedback.textContent = "Please fill in all required fields before sending your order.";
    return;
  }

  const formData = new FormData(orderForm);
  const service = selectedService();

  activeRequestFormData = formData;
  activeRequestService = service;
  requestPdfBlob = null;
  requestPdfFilename = "";
  requestPdfAutoDownloaded = false;
  saveOrderPdfButton.hidden = true;
  populateRequestDocument(formData, service);
  orderPreviewStatus.textContent = "READY TO SEND";
  orderPreviewIntro.textContent = "Review the details. Choose Edit request to make changes, or Send request to submit it.";
  orderPreviewIntro.classList.remove("is-error");
  document.getElementById("order-preview-title").textContent = "Review your commission request";
  sendOrderRequestButton.disabled = false;
  sendOrderRequestButton.textContent = "Send request";
  sendOrderRequestButton.hidden = false;
  editOrderButton.hidden = false;
  saveOrderPdfButton.hidden = true;
  orderForm.hidden = true;
  orderPreview.hidden = false;
  orderPreview.scrollIntoView({ behavior: "smooth", block: "start" });
});

sendOrderRequestButton.addEventListener("click", async () => {
  if (!activeRequestFormData) return;
  await sendCommissionRequest(activeRequestFormData, activeRequestService);
});

saveOrderPdfButton.addEventListener("click", () => {
  downloadRequestPdf();
});

editOrderButton.addEventListener("click", () => {
  orderPreview.hidden = true;
  orderForm.hidden = false;
  orderForm.scrollIntoView({ behavior: "smooth", block: "start" });
});
orderForm.addEventListener("input", updateOrderState);
orderForm.addEventListener("change", updateOrderState);
document.getElementById("choose-order-files").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => {
  addReferenceFiles(fileInput.files || []);
  fileInput.value = "";
});

fileDropzone.addEventListener("click", () => fileDropzone.focus());
fileDropzone.addEventListener("dragover", (event) => {
  event.preventDefault();
  fileDropzone.classList.add("is-dragging");
});
fileDropzone.addEventListener("dragleave", (event) => {
  if (!fileDropzone.contains(event.relatedTarget)) fileDropzone.classList.remove("is-dragging");
});
fileDropzone.addEventListener("drop", (event) => {
  event.preventDefault();
  fileDropzone.classList.remove("is-dragging");
  addReferenceFiles(event.dataTransfer.files || []);
});

fileDropzone.addEventListener("paste", (event) => {
  const files = clipboardFiles(event.clipboardData);
  if (!files.length) return;
  addReferenceFiles(files);
  event.preventDefault();
});

updateOrderState();