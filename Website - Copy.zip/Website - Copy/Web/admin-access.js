(() => {
  const accessKey = "snowiAdminPanelAuthorized";
  const secretPhrase = "adminpanel1809";
  const currentPage = window.location.pathname.split("/").pop().toLowerCase();

  if (currentPage === "admin.html") {
    let authorized = false;
    try {
      authorized = sessionStorage.getItem(accessKey) === "granted";
    } catch (error) {
      console.error("Unable to verify Admin Panel access in this browser session.", error);
    }

    if (!authorized) {
      window.location.replace("order.html");
    }
    return;
  }

  if (currentPage === "order.html" && new URLSearchParams(window.location.search).has(secretPhrase)) {
    sessionStorage.setItem(accessKey, "granted");
    window.location.replace("admin.html");
  }
})();