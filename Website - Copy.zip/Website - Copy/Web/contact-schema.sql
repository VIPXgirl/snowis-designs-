create extension if not exists pgcrypto;

create table if not exists public.contact_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.contact_submissions (
  id uuid primary key default gen_random_uuid(),
  visitor_id uuid not null references auth.users(id) on delete cascade,
  customer_name text not null check (char_length(trim(customer_name)) between 1 and 120),
  phone text not null check (char_length(trim(phone)) between 1 and 60),
  message text not null check (char_length(trim(message)) between 1 and 4000),
  status text not null default 'new' check (status in ('new', 'replied')),
  created_at timestamptz not null default now()
);

create table if not exists public.commission_requests (
  id uuid primary key default gen_random_uuid(),
  visitor_id uuid not null references auth.users(id) on delete cascade,
  customer_name text not null check (char_length(trim(customer_name)) between 1 and 120),
  customer_email text not null check (char_length(trim(customer_email)) between 3 and 320),
  service_category text not null check (char_length(trim(service_category)) between 1 and 120),
  service_name text not null check (char_length(trim(service_name)) between 1 and 200),
  listed_price text not null check (char_length(trim(listed_price)) between 1 and 120),
  quantity integer not null check (quantity between 1 and 20),
  preferred_timing text not null check (char_length(trim(preferred_timing)) between 1 and 80),
  creative_brief text not null check (char_length(trim(creative_brief)) between 12 and 4000),
  reference_files jsonb not null default '[]'::jsonb check (jsonb_typeof(reference_files) = 'array'),
  status text not null default 'new' check (status in ('new', 'replied')),
  created_at timestamptz not null default now()
);

create index if not exists contact_submissions_created_at_idx
  on public.contact_submissions (created_at desc);

create index if not exists commission_requests_created_at_idx
  on public.commission_requests (created_at desc);

create or replace function public.is_contact_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.contact_admins
    where user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_contact_admin() from public;
grant execute on function public.is_contact_admin() to authenticated;

alter table public.contact_admins enable row level security;
alter table public.contact_submissions enable row level security;
alter table public.commission_requests enable row level security;

drop policy if exists "Admins can read their own contact membership" on public.contact_admins;
create policy "Admins can read their own contact membership"
  on public.contact_admins for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists "Admins can read contact submissions" on public.contact_submissions;
create policy "Admins can read contact submissions"
  on public.contact_submissions for select to authenticated
  using ((select public.is_contact_admin()));

drop policy if exists "Visitors can create contact submissions" on public.contact_submissions;
create policy "Visitors can create contact submissions"
  on public.contact_submissions for insert to authenticated
  with check (
    visitor_id = (select auth.uid())
    and status = 'new'
  );

drop policy if exists "Admins can update contact submission status" on public.contact_submissions;
create policy "Admins can update contact submission status"
  on public.contact_submissions for update to authenticated
  using ((select public.is_contact_admin()))
  with check ((select public.is_contact_admin()));

drop policy if exists "Admins can read commission requests" on public.commission_requests;
create policy "Admins can read commission requests"
  on public.commission_requests for select to authenticated
  using ((select public.is_contact_admin()));

drop policy if exists "Visitors can create commission requests" on public.commission_requests;
create policy "Visitors can create commission requests"
  on public.commission_requests for insert to authenticated
  with check (
    visitor_id = (select auth.uid())
    and status = 'new'
  );

drop policy if exists "Admins can update commission request status" on public.commission_requests;
create policy "Admins can update commission request status"
  on public.commission_requests for update to authenticated
  using ((select public.is_contact_admin()))
  with check ((select public.is_contact_admin()));

grant select on public.contact_admins to authenticated;
grant select, insert, update on public.contact_submissions to authenticated;
grant select, insert, update on public.commission_requests to authenticated;

do $$
begin
  begin
    alter publication supabase_realtime add table public.contact_submissions;
  exception
    when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.commission_requests;
  exception
    when duplicate_object then null;
  end;
end;
$$;
