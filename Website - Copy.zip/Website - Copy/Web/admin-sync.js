const adminDataKey = "adminPageData";
const comingSoonPricingCategories = new Set([
  "🤍 Icons ❄️",
  "🤍 Logos ❄️",
  "🤍 Wallpapers ❄️",
  "🤍 Emojis ❄️",
  "🤍 Banners ❄️",
  "🤍 Sticker bundles ❄️",
  "🤍 Emoji bundles ❄️"
]);
const legacyDefaultFaqQuestions = [
  "How long does it take to process an order?",
  "Can I request a custom design?",
  "Do you offer delivery?"
];
const designServiceImageMatchers = [
  /simple\s+pfp|avatar/i,
  /detailed\s+pfp/i,
  /banner/i,
  /emoji/i,
  /sticker|icon/i,
  /character/i,
  /wallpaper|custom picture/i,
  /logo|branding/i
];

function isLegacyDefaultFaqSet(faqs) {
  if (!Array.isArray(faqs) || faqs.length !== legacyDefaultFaqQuestions.length) {
    return false;
  }

  return faqs.every((faq, index) => faq && faq.question === legacyDefaultFaqQuestions[index]);
}

function renderPricingCard(item) {
  const isBundle = item.variant === "bundle";
  if (isBundle) {
    return `
      <div class="bundle-card">
        ${item.emoji ? `<span class="bundle-icon">${item.emoji}</span>` : ""}
        <h4>${item.name || ""}</h4>
        ${item.description ? `<p class="bundle-description">${item.description}</p>` : ""}
        ${item.includes ? `<p class="bundle-includes">${item.includes}</p>` : ""}
        <p class="bundle-price">${item.price || ""}</p>
      </div>
    `;
  }
  return `
    <div class="item-card">
      ${item.emoji ? `<span class="item-emoji">${item.emoji}</span>` : ""}
      <h4 class="item-name">${item.name || ""}</h4>
      ${item.description ? `<p class="item-bio">${item.description}</p>` : ""}
      ${item.includes ? `<p class="bundle-includes">${item.includes}</p>` : ""}
      <p class="item-price">${item.price || ""}</p>
    </div>
  `;
}


window.addEventListener("DOMContentLoaded", () => {
  const isHomePage = document.querySelector(".hero-section");
  const isGalleryPage = document.querySelector(".gallery-page-section");
  const isDesignServicesPage = document.querySelector(".design-services-page-section");
  if (!isHomePage && !isGalleryPage && !isDesignServicesPage) return;

  const adminDataRaw = localStorage.getItem(adminDataKey);
  const publishedData = window.SNOWI_PUBLISHED_DATA;
  // Design services and home pages still need to wire up work galleries even with no saved admin data.
  if (!adminDataRaw && !publishedData && !isDesignServicesPage && !isHomePage) return;

  let adminData = publishedData && typeof publishedData === "object" ? publishedData : {};
  if (adminDataRaw) {
    try {
      adminData = JSON.parse(adminDataRaw);
    } catch (error) {
      console.error("Saved admin data was corrupted and could not be loaded. Try Reset to Defaults in the admin panel.", error);
      adminData = {};
    }
  }

  try {
    const workLightbox = document.getElementById("profile-lightbox");
    const workLightboxGallery = document.getElementById("profile-lightbox-gallery");
    const workLightboxClose = document.querySelector(".profile-lightbox-close");
    const workLightboxPrev = document.querySelector(".profile-lightbox-arrow-left");
    const workLightboxNext = document.querySelector(".profile-lightbox-arrow-right");
    const workLightboxCounter = document.getElementById("profile-lightbox-counter");
    let workGalleryImages = [];
    let workGalleryIndex = 0;

    function renderWorkGallerySlide() {
      if (workLightboxGallery) {
        const src = workGalleryImages[workGalleryIndex];
        workLightboxGallery.innerHTML = src
          ? `<div class="emoji-gallery-slide has-photo"><img src="${src}" alt="Design work sample"></div>`
          : `<div class="emoji-gallery-slide work-gallery-empty">No work images uploaded yet.</div>`;
      }
      if (workLightboxCounter) {
        workLightboxCounter.textContent = workGalleryImages.length > 1 ? `${workGalleryIndex + 1} / ${workGalleryImages.length}` : "";
      }
      const showArrows = workGalleryImages.length > 1;
      if (workLightboxPrev) workLightboxPrev.style.display = showArrows ? "" : "none";
      if (workLightboxNext) workLightboxNext.style.display = showArrows ? "" : "none";
    }

    function openWorkGallery(images) {
      if (!workLightbox || !workLightboxGallery) return;
      workGalleryImages = images;
      workGalleryIndex = 0;
      renderWorkGallerySlide();
      workLightbox.classList.add("is-open");
      workLightbox.setAttribute("aria-hidden", "false");
    }

    function closeWorkGallery() {
      if (!workLightbox) return;
      workLightbox.classList.remove("is-open");
      workLightbox.setAttribute("aria-hidden", "true");
    }

    if (workLightboxClose) workLightboxClose.addEventListener("click", closeWorkGallery);
    if (workLightbox) {
      workLightbox.addEventListener("click", (event) => {
        if (event.target === workLightbox) closeWorkGallery();
      });
    }
    if (workLightboxPrev) {
      workLightboxPrev.addEventListener("click", () => {
        if (!workGalleryImages.length) return;
        workGalleryIndex = (workGalleryIndex - 1 + workGalleryImages.length) % workGalleryImages.length;
        renderWorkGallerySlide();
      });
    }
    if (workLightboxNext) {
      workLightboxNext.addEventListener("click", () => {
        if (!workGalleryImages.length) return;
        workGalleryIndex = (workGalleryIndex + 1) % workGalleryImages.length;
        renderWorkGallerySlide();
      });
    }
    document.addEventListener("keydown", (event) => {
      if (!workLightbox || !workLightbox.classList.contains("is-open")) return;
      if (event.key === "Escape") closeWorkGallery();
      if (event.key === "ArrowLeft" && workLightboxPrev) workLightboxPrev.click();
      if (event.key === "ArrowRight" && workLightboxNext) workLightboxNext.click();
    });

    const heroTitle = document.querySelector(".hero-details .title");
    const heroSubtitle = document.querySelector(".hero-details .subtitle");
    const heroDescription = document.querySelector(".hero-details .description");
    const heroButton = document.querySelector(".hero-details .order-now");
    const heroImage = document.querySelector(".hero-image");
    const aboutImage = document.querySelector(".about-image");
    const aboutTitle = document.querySelector(".about-details .section-title");
    const aboutText = document.querySelector(".about-details > .text");
    const galleryIntro = document.querySelector(".gallery-intro");
    const pricingIntro = document.querySelector(".pricing-header .pricing-intro");
    const contactTitle = document.querySelector(".contact-section .section-title");
    const contactText = document.querySelector(".contact-section .section-text");
    const footerCopyright = document.querySelector(".copyright-text");
    const faqItems = document.querySelectorAll(".faq-item");
    const contactLinks = document.querySelectorAll(".contact-info a");
    const galleryImages = document.querySelectorAll(".gallery-preview");
    const galleryCards = document.querySelectorAll(".gallery-card");
    const designServiceCards = document.querySelectorAll(".work-card");
    const pricingCategoriesPanel = document.querySelector(".pricing-pairs-panel");
    const faqList = document.querySelector(".faq-list");

    const heroSubtitleText = adminData.heroSubtitle ?? adminData.heroText ?? "";
    const heroDescriptionText = adminData.heroDescription ?? adminData.heroText ?? "";

    if (heroTitle) {
      heroTitle.textContent = adminData.heroTitle ?? "";
    }

    if (heroSubtitle) {
      heroSubtitle.textContent = heroSubtitleText;
    }

    if (heroDescription) {
      heroDescription.textContent = heroDescriptionText;
    }

    if (heroButton) {
      heroButton.textContent = adminData.heroButtonText ?? "";
    }

    if (heroImage && adminData.heroImage) {
      heroImage.src = adminData.heroImage;
      heroImage.alt = "Hero image";
      heroImage.parentElement.style.display = "block";
    }

    if (aboutImage && adminData.aboutImage) {
      aboutImage.src = adminData.aboutImage;
      aboutImage.alt = "About image";
    }

    if (Array.isArray(adminData.galleryImages)) {
      galleryImages.forEach((preview, index) => {
        if (adminData.galleryImages[index]) {
          preview.innerHTML = `<img src="${adminData.galleryImages[index]}" alt="Gallery image ${index + 1}" class="admin-managed-image">`;
        }
      });
    }

    if (Array.isArray(adminData.pricingCategories)) {
      adminData.pricingCategories = adminData.pricingCategories.map((category) => category.title === "🤍 Stickers ❄️"
        ? { ...category, items: (category.items || []).filter((item) => item.name === "Simple sticker") }
        : category);
    }

    designServiceCards.forEach((card, index) => {
      const rawImages = Array.isArray(adminData.designImages) ? adminData.designImages[index] : null;
      const directImages = Array.isArray(rawImages) ? rawImages.filter(Boolean) : (rawImages ? [rawImages] : []);
      const matcher = designServiceImageMatchers[index];
      const pricingImages = directImages.length || !matcher || !Array.isArray(adminData.pricingCategories)
        ? []
        : adminData.pricingCategories.flatMap((category) =>
            (category.items || [])
              .filter((item) => matcher.test(`${category.title || ""} ${item.name || ""}`))
              .flatMap((item) => Array.isArray(item.images) ? item.images : (item.images ? [item.images] : []))
          ).filter(Boolean);
      const imageEntries = directImages.length ? directImages : pricingImages;
      const imagesPromise = typeof resolveImageEntries === "function"
        ? resolveImageEntries(imageEntries)
        : Promise.resolve(imageEntries.filter((entry) => typeof entry === "string" && entry.startsWith("data:")));

      const viewButton = document.createElement("button");
      viewButton.type = "button";
      viewButton.className = "work-gallery-trigger";
      viewButton.textContent = imageEntries.length ? `📷 View current work (${imageEntries.length})` : "📷 View current work";
      viewButton.addEventListener("click", async () => openWorkGallery(await imagesPromise));
      card.appendChild(viewButton);

      card.classList.add("work-card-clickable");
      card.addEventListener("click", (event) => {
        if (event.target.closest(".work-gallery-trigger")) return;
        imagesPromise.then(openWorkGallery);
      });

      imagesPromise.then((images) => {
        viewButton.textContent = images.length ? `📷 View current work (${images.length})` : "📷 View current work";
        if (!images.length) return;
        const thumb = document.createElement("img");
        thumb.src = images[0];
        thumb.alt = "Design service image";
        thumb.className = "admin-managed-image design-service-image";
        card.prepend(thumb);
      });
    });


    if (Array.isArray(adminData.galleryCards) && adminData.galleryCards.length) {
      galleryCards.forEach((card, index) => {
        const item = adminData.galleryCards[index];
        if (!item) return;
        const title = card.querySelector(".name");
        const description = card.querySelector(".text");
        if (item.title && title) title.textContent = item.title;
        if (item.description && description) description.textContent = item.description;
      });
    }

    if (Array.isArray(adminData.designServices) && adminData.designServices.length) {
      designServiceCards.forEach((card, index) => {
        const item = adminData.designServices[index];
        if (!item) return;
        const title = card.querySelector(".name");
        const description = card.querySelector(".text");
        const tag = card.querySelector(".work-tag");
        if (item.title && title) title.textContent = item.title;
        if (item.description && description) description.textContent = item.description;
        if (item.tag && tag) tag.textContent = item.tag;
      });
    }

    const textUpdates = [
      [aboutTitle, adminData.aboutTitle],
      [aboutText, adminData.aboutText],
      [galleryIntro, adminData.galleryIntro],
      [pricingIntro, adminData.pricingIntro],
      [contactTitle, adminData.contactTitle],
      [contactText, adminData.contactText],
      [footerCopyright, adminData.footerCopyright]
    ];
    textUpdates.forEach(([element, value]) => {
      if (element && value) element.textContent = value;
    });

    if (pricingCategoriesPanel && Array.isArray(adminData.pricingCategories) && adminData.pricingCategories.length) {
      pricingCategoriesPanel.innerHTML = adminData.pricingCategories.map((category) => {
        const isComingSoon = comingSoonPricingCategories.has(category.title);
        const isCharacterArt = category.title && category.title.includes("Character art");
        return `
        <div class="pricing-category${isComingSoon ? " is-coming-soon" : ""}${isCharacterArt ? " is-character-art" : ""}">
          <div class="category-heading"><h3>${category.title || ""}</h3></div>
          <div class="${category.gridClass || "items-grid"}">
            ${(category.items || []).map(renderPricingCard).join("")}
          </div>
          ${isComingSoon ? '<div class="coming-soon-tape"><span>Coming soon</span></div>' : ""}
        </div>`;
      }).join("");

      if (typeof resolveImageEntries === "function") {
        const categoryElements = pricingCategoriesPanel.querySelectorAll(".pricing-category");
        categoryElements.forEach((categoryElement, index) => {
          const category = adminData.pricingCategories[index];
          const imageEntries = Array.from(new Set((category.items || [])
            .flatMap((item) => Array.isArray(item.images) ? item.images : [])
            .filter(Boolean)));
          if (!imageEntries.length) return;

          resolveImageEntries(imageEntries).then((images) => {
            if (!images.length) return;

            const slideshow = document.createElement("div");
            slideshow.className = "pricing-category-slideshow";
            slideshow.setAttribute("aria-hidden", "true");

            const track = document.createElement("div");
            track.className = "pricing-category-track";
            const imageGroup = document.createElement("div");
            imageGroup.className = "pricing-category-image-group";
            const slideWidth = 190;
            const slideGap = 12;
            const minimumSlideCount = Math.ceil((categoryElement.clientWidth + slideGap) / (slideWidth + slideGap));
            const groupImages = Array.from({ length: Math.ceil(minimumSlideCount / images.length) }, () => images).flat();
            track.style.setProperty("--category-slide-width", `${slideWidth}px`);

            groupImages.forEach((src) => {
              const image = document.createElement("img");
              image.className = "pricing-category-slide";
              image.alt = "";
              image.decoding = "async";
              image.src = src;
              imageGroup.appendChild(image);
            });

            track.append(imageGroup, imageGroup.cloneNode(true));
            slideshow.appendChild(track);
            categoryElement.prepend(slideshow);

            const trackWidth = imageGroup.getBoundingClientRect().width;
            track.style.setProperty("--category-track-start", `-${trackWidth}px`);
            track.style.setProperty("--category-track-duration", `${Math.max(28, trackWidth / 32)}s`);
            if (images.length > 1 && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
              track.classList.add("is-moving");
            }
          });
        });
      }
    }

    if (pricingCategoriesPanel) {
      const priceCards = pricingCategoriesPanel.querySelectorAll(".item-card, .bundle-card");
      const flattenedPricingItems = Array.isArray(adminData.pricingCategories)
        ? adminData.pricingCategories.flatMap((category) => (category.items || []).map((item, itemIndex) => ({
            categoryTitle: category.title,
            item,
            itemIndex
          })))
        : [];
      priceCards.forEach((card, index) => {
        const pricingEntry = flattenedPricingItems[index];
        const pricingItem = pricingEntry && pricingEntry.item;
        const imageEntries = pricingItem && Array.isArray(pricingItem.images) ? pricingItem.images.filter(Boolean) : [];
        const imagesPromise = typeof resolveImageEntries === "function"
          ? resolveImageEntries(imageEntries)
          : Promise.resolve(imageEntries.filter((entry) => typeof entry === "string" && entry.startsWith("data:")));

        card.classList.add("work-card-clickable");
        if (imageEntries.length) card.classList.add("has-work-images");
        card.addEventListener("click", async () => {
          openWorkGallery(await imagesPromise);
        });
      });
    }

    if (Array.isArray(adminData.faqData) && adminData.faqData.length) {
      faqItems.forEach((item, index) => {
        const faq = adminData.faqData[index];
        if (!faq) return;
        const question = item.querySelector(".faq-question");
        const answer = item.querySelector(".faq-answer");
        if (faq.question && question) question.textContent = faq.question;
        if (faq.answer && answer) answer.textContent = faq.answer;
      });
    }

    if (Array.isArray(adminData.contactLinks) && adminData.contactLinks.length) {
      contactLinks.forEach((link, index) => {
        const contact = adminData.contactLinks[index];
        if (!contact) return;
        if (contact.label) link.textContent = contact.label;
        if (contact.url) link.href = contact.url;
      });
    }

  } catch (error) {
    console.error("Could not apply admin panel data:", error);
  }
});
