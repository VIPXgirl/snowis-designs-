# Commission Request Email Setup

Customers can fill in and review the order form without signing in. The request is emailed only after they choose **Send request**. When sending succeeds, the page thanks them and asks them to wait for a reply at the email address they provided. The form emails the request details, generated PDF, and every selected reference file to `snowihouse3@gmail.com` using FormSubmit.

The order page must be opened from an HTTP/HTTPS address, not directly as a `file://` URL. For local testing, run the site with a local web server (for example, VS Code Live Server).

On the first live submission, FormSubmit sends an activation email to `snowihouse3@gmail.com`. Open it and approve the form address. Each request then arrives at that address with the PDF and original reference files attached. Image attachments can be previewed by the email app; other file types can be downloaded. The customer also automatically downloads a local PDF copy containing the request details and reference filenames. Reference files are emailed as separate attachments and are not embedded in the PDF or stored by the website.

To review submitted requests, open the **05 Commission requests** section in the Admin Panel and choose **Open Gmail inbox**. Requests are delivered by email and are not stored in the website's admin panel.

## Admin Panel access

Open the Order Now page with the agreed secret query phrase in its URL to enter the Admin Panel in the same browser tab. Access lasts for that tab's session. This is only a hidden route: the phrase is present in the site's client-side code, so it is not secure authentication and should not be used to protect sensitive data.
