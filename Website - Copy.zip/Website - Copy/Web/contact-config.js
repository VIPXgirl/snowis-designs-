window.SNOWI_CONTACT_CONFIG = {
  supabaseUrl: "https://fntqnezalbxgeqmiekmc.supabase.co",
  supabaseAnonKey: "sb_publishable_BPUvcMzTqybmubYMrIKXGQ_fg9AzPZ4"
};
