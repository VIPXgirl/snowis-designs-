const defaultAdminData = {
  heroTitle: "Snowi's house",
  heroSubtitle: "Custom graphics for everyone—logos, banners, emojis, thumbnails, and everything in between! ✨",
  heroDescription: "",
  heroButtonText: "Order Now",
  aboutTitle: "🤍Who am I?❄️",
  aboutText: "I'm the owner of the Discord community, YouTuber and a digital artist creating custom graphics for Discord, YouTube, businesses, creators, and more. 💫",
  galleryIntro: "Explore some of my custom artwork and creative projects. Each piece is created with care and tailored to your ideas and preferences. 💕",
  pricingIntro: "Take a look at my available design services and pricing!",
  contactTitle: "Follow me",
  contactText: "Follow along for new artwork, updates, and design work.",
  footerCopyright: "© 2026 Snowi's house",
  heroImage: "",
  aboutImage: "images/about-image.jpg",
  galleryImages: ["", "", ""],
  designImages: [[], [], [], [], [], [], [], []],
  pricingCategories: [
    {
      title: "🤍 Profile pictures ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🖼️", name: "Simple PFP / avatar", description: "Clean avatar art for socials, gaming, or branding.", price: "10–15€" },
        { variant: "item", emoji: "🧑‍🎨", name: "Detailed PFP", description: "A more polished portrait with stronger detail and contrast.", price: "18–25€" }
      ]
    },
    {
      title: "🤍 Character art ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🧍", name: "Custom character bust", description: "A focused portrait with expression, mood, and style details.", price: "12–18€" },
        { variant: "item", emoji: "🧍", name: "Custom character half body", description: "Mid-torso character art with pose, personality, and composition.", price: "18–25€" },
        { variant: "item", emoji: "🧍", name: "Full body character", description: "A complete character design with full form and presentation.", price: "25–35€" }
      ]
    },
    {
      title: "🤍 Stickers ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🏷️", name: "Simple sticker", description: "A single cute sticker for merch, posts, or branding.", price: "4€" }
      ]
    },
    {
      title: "🤍 Icons ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🔵", name: "Simple icon", description: "A clean symbol for apps, labels, or visual branding.", price: "5–8€" },
        { variant: "item", emoji: "✨", name: "Detailed icon", description: "A more polished symbol with extra detail and depth.", price: "8–12€" }
      ]
    },
    {
      title: "🤍 Logos ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🏷️", name: "Simple logo", description: "A minimal logo concept for a brand, shop, or identity.", price: "15–25€" },
        { variant: "item", emoji: "✨", name: "Detailed logo", description: "A more refined logo with stronger polish and branding impact.", price: "25–40€" }
      ]
    },
    {
      title: "🤍 Wallpapers ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🖼️", name: "Simple custom wallpaper", description: "A clean wallpaper tailored to your theme or device setup.", price: "10–18€" },
        { variant: "item", emoji: "🎨", name: "Detailed custom wallpaper", description: "A richer wallpaper with more detail, mood, and visual depth.", price: "20–35€" }
      ]
    },
    {
      title: "🤍 Emojis ❄️",
      gridClass: "emoji-services-grid",
      items: [
        { variant: "item", emoji: "😊", name: "Simple emoji", description: "A single expressive emoji illustration for a cute or branded vibe.", price: "3€" },
        { variant: "bundle", emoji: "🎨", name: "Small Pack", description: "A small collection of expressive emoji illustrations for a cute or branded vibe.", includes: "5 emojis", price: "12€" },
        { variant: "bundle", emoji: "💖", name: "Medium Pack", description: "A larger set of expressive emoji illustrations for a cute or branded vibe.", includes: "10 emojis", price: "23€" }
      ]
    },
    {
      title: "🤍 Banners ❄️",
      gridClass: "items-grid",
      items: [
        { variant: "item", emoji: "🎮", name: "Simple banner", description: "A clean promotion banner for socials, streams, or events.", price: "10–18€" },
        { variant: "item", emoji: "🖼️", name: "Detailed banner", description: "A more detailed banner with stronger composition and visual impact.", price: "20–30€" }
      ]
    },
    {
      title: "🤍 Sticker bundles ❄️",
      gridClass: "bundle-grid",
      items: [
        { variant: "bundle", emoji: "🌱", name: "Mini Pack", includes: "3 stickers", price: "10€" },
        { variant: "bundle", emoji: "⭐", name: "Small Pack", includes: "5 stickers", price: "15€" },
        { variant: "bundle", emoji: "💖", name: "Cute Pack", includes: "8 stickers", price: "22€" },
        { variant: "bundle", emoji: "🎨", name: "Big Pack", includes: "12 stickers", price: "30€" },
        { variant: "bundle", emoji: "💎", name: "Mega Pack", includes: "20 stickers", price: "45€" }
      ]
    },
    {
      title: "🤍 Emoji bundles ❄️",
      gridClass: "bundle-grid",
      items: [
        { variant: "bundle", emoji: "🌱", name: "Mini Pack", includes: "3 emojis", price: "8€" },
        { variant: "bundle", emoji: "⭐", name: "Small Pack", includes: "5 emojis", price: "12€" },
        { variant: "bundle", emoji: "💖", name: "Creator Pack", includes: "8 emojis", price: "18€" },
        { variant: "bundle", emoji: "🎨", name: "Big Pack", includes: "12 emojis", price: "25€" },
        { variant: "bundle", emoji: "💎", name: "Mega Pack", includes: "20 emojis", price: "38€" }
      ]
    }
  ],
  faqData: [],
  contactLinks: [],
  galleryCards: [],
  designServices: []
};

const stateKey = "adminPageData";
const previewStage = document.getElementById("preview-stage");
const previewScreen = document.getElementById("preview-screen-wrap");
const previewFrame = document.getElementById("storefront-preview");
const saveButton = document.getElementById("save-changes");
const resetButton = document.getElementById("reset-data");
const heroImageInput = document.getElementById("hero-image");
const aboutImageInput = document.getElementById("about-image");
const galleryImageInputs = [1, 2, 3].map((index) => document.getElementById(`gallery-image-${index}`));
const designServiceNames = [
  "Simple PFP / avatar",
  "Detailed PFP",
  "Server banners",
  "Custom emojis",
  "Sticker packs & icons",
  "Character art",
  "Custom pictures",
  "Logos & branding"
];
const textFields = ["heroTitle", "heroSubtitle", "heroDescription", "heroButtonText", "aboutTitle", "aboutText", "galleryIntro", "pricingIntro", "contactTitle", "contactText", "footerCopyright"];
const jsonFields = ["pricingCategories", "faqData", "contactLinks", "galleryCards"];
const saveState = document.getElementById("admin-save-state");
const saveStateText = document.getElementById("save-state-text");
const adminToast = document.getElementById("admin-toast");
let toastTimeout;

function showToast(message) {
  if (!adminToast) return;
  adminToast.textContent = message;
  adminToast.classList.add("is-visible");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => adminToast.classList.remove("is-visible"), 2800);
}

function setSaveState(state, message) {
  if (!saveState || !saveStateText) return;
  saveState.dataset.state = state;
  saveStateText.textContent = message;
}

function updateDashboard() {
  const data = getData();
  const serviceImages = (data.pricingCategories || []).reduce((total, category) => total +
    (category.items || []).reduce((itemTotal, item) => itemTotal + (Array.isArray(item.images) ? item.images.length : 0), 0), 0);
  const designImages = (data.designImages || []).reduce((total, images) => total + images.length, 0);
  const siteImages = [data.heroImage, data.aboutImage, ...(data.galleryImages || [])].filter(Boolean).length;
  document.getElementById("stat-fields").textContent = String(textFields.length + jsonFields.length);
  document.getElementById("stat-categories").textContent = String((data.pricingCategories || []).length);
  document.getElementById("stat-images").textContent = String(serviceImages + designImages + siteImages);
}

function setActiveSection(sectionId) {
  document.querySelectorAll("[data-admin-section]").forEach((section) => {
    section.hidden = section.id !== sectionId;
  });
  document.querySelector(".admin-grid").classList.toggle("is-requests-view", sectionId === "commission-requests");
  document.querySelectorAll("[data-admin-target]").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.adminTarget === sectionId);
  });
}

function filterAdminSections(query) {
  const normalizedQuery = query.trim().toLowerCase();
  const sections = Array.from(document.querySelectorAll("[data-admin-section]"));
  const matches = sections.filter((section) => !normalizedQuery || section.textContent.toLowerCase().includes(normalizedQuery));
  if (normalizedQuery && matches.length) setActiveSection(matches[0].id);
  document.getElementById("admin-search-empty").hidden = normalizedQuery.length === 0 || matches.length > 0;
  sections.forEach((section) => {
    section.hidden = !matches.includes(section) || (normalizedQuery ? section !== matches[0] : section.id !== document.querySelector(".admin-nav-button.is-active")?.dataset.adminTarget);
  });
}

function normalizeDesignImages(rawDesignImages) {
  const source = Array.isArray(rawDesignImages) ? rawDesignImages : defaultAdminData.designImages;
  return designServiceNames.map((_, index) => {
    const entry = source[index];
    if (Array.isArray(entry)) return entry.filter(Boolean);
    return entry ? [entry] : [];
  });
}

function normalizePricingCategories(rawCategories) {
  const source = Array.isArray(rawCategories) ? rawCategories : defaultAdminData.pricingCategories;
  return JSON.parse(JSON.stringify(source)).map((category) => category.title === "🤍 Stickers ❄️"
    ? { ...category, items: (category.items || []).filter((item) => item.name === "Simple sticker") }
    : category);
}

function getData() {
  const savedData = JSON.parse(localStorage.getItem(stateKey) || "null") || window.SNOWI_PUBLISHED_DATA || {};
  return {
    ...defaultAdminData,
    ...savedData,
    galleryImages: Array.isArray(savedData.galleryImages) ? savedData.galleryImages : [...defaultAdminData.galleryImages],
    designImages: normalizeDesignImages(savedData.designImages),
    pricingCategories: normalizePricingCategories(savedData.pricingCategories)
  };
}

function setData(data) {
  try {
    localStorage.setItem(stateKey, JSON.stringify(data));
    return true;
  } catch (error) {
    alert("Could not save: storage is full. Try removing some uploaded images and saving again.");
    return false;
  }
}

function syncPricingCategoriesField(data) {
  const field = document.getElementById("pricing-categories");
  if (field) field.value = JSON.stringify(data.pricingCategories, null, 2);
}

function prepareImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const image = new Image();
      image.onload = () => {
        const scale = Math.min(1, 900 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(image.width * scale);
        canvas.height = Math.round(image.height * scale);
        canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
        const keepsTransparency = file.type === "image/png" || file.type === "image/webp" || file.type === "image/gif";
        // WebP keeps transparency but compresses far smaller than PNG, leaving room for many photos per service.
        resolve(keepsTransparency ? canvas.toDataURL("image/webp", 0.85) : canvas.toDataURL("image/jpeg", 0.72));
      };
      image.onerror = reject;
      image.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function buildPreview() {
  previewFrame.src = `index.html?adminPreview=${Date.now()}`;

  renderPricingImagesEditor();
  updateDashboard();
}

function fitPreviewViewport() {
  const isPhone = previewStage.dataset.device === "phone";
  const viewportWidth = isPhone ? 390 : 1280;
  const viewportHeight = isPhone ? 844 : 820;
  const scale = Math.min(1, previewStage.clientWidth / viewportWidth);
  const phoneFrame = isPhone ? 12 : 0;
  previewScreen.style.width = `${viewportWidth * scale + phoneFrame}px`;
  previewScreen.style.height = `${viewportHeight * scale + phoneFrame}px`;
  previewFrame.style.width = `${viewportWidth}px`;
  previewFrame.style.height = `${viewportHeight}px`;
  previewFrame.style.transform = `scale(${scale})`;
}

function renderPricingImagesEditor() {
  const container = document.getElementById("pricing-images-editor");
  if (!container) return;
  const data = getData();
  container.innerHTML = (data.pricingCategories || []).map((category, catIndex) => `
    <div class="pricing-images-category">
      <h4>${category.title || `Category ${catIndex + 1}`}</h4>
      ${(category.items || []).map((item, itemIndex) => {
        const imageIds = Array.isArray(item.images) ? item.images.filter(Boolean) : [];
        return `
          <div class="pricing-images-item">
            <p class="pricing-images-item-name">${item.name || "Untitled item"}</p>
            <input type="file" accept="image/*" multiple class="pricing-item-image-input" data-cat-index="${catIndex}" data-item-index="${itemIndex}">
            <div class="design-work-preview-thumbs">
              ${imageIds.length
                ? imageIds.map((id, imageIndex) => `
                  <div class="design-work-thumb">
                    <img alt="${item.name || "Item"} image ${imageIndex + 1}" class="preview-image pricing-thumb-img" data-image-id="${id}">
                    <button type="button" class="remove-pricing-image" data-cat-index="${catIndex}" data-item-index="${itemIndex}" data-image-index="${imageIndex}">Remove</button>
                  </div>
                `).join("")
                : `<p>No images uploaded yet.</p>`}
            </div>
          </div>
        `;
      }).join("")}
    </div>
  `).join("");

  container.querySelectorAll(".pricing-thumb-img").forEach((imgEl) => {
    resolveImageEntry(imgEl.dataset.imageId).then((dataUrl) => {
      if (dataUrl) imgEl.src = dataUrl;
    });
  });
}

function loadFields() {
  const data = getData();
  textFields.forEach((key) => {
    const field = document.getElementById(key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`));
    if (field) field.value = data[key] || "";
  });
  jsonFields.forEach((key) => {
    const field = document.getElementById(key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`));
    if (field) field.value = data[key] ? JSON.stringify(data[key], null, 2) : "";
  });
}

function updateDataFromInputs() {
  const data = getData();
  textFields.forEach((key) => {
    const field = document.getElementById(key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`));
    if (field) data[key] = field.value;
  });
  jsonFields.forEach((key) => {
    const field = document.getElementById(key.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`));
    if (!field) return;
    if (!field.value.trim()) {
      data[key] = [];
      return;
    }
    try {
      data[key] = JSON.parse(field.value);
    } catch (error) {
      alert(`Please fix the JSON in ${field.id}.`);
      throw error;
    }
  });

  const saved = setData(data);
  buildPreview();
  return saved;
}

async function downloadBackup() {
  if (!updateDataFromInputs()) throw new Error("Your changes could not be saved before creating the backup.");
  setSaveState("saved", "All changes saved");
  const data = await getExportData();
  const backup = { format: "snowi-admin-backup", version: 1, exportedAt: new Date().toISOString(), data };
  downloadFile(`snowi-site-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(backup, null, 2), "application/json");
  showToast("Backup downloaded with uploaded artwork.");
}

async function getExportData() {
  const data = getData();
  data.pricingCategories = await Promise.all((data.pricingCategories || []).map(async (category) => ({
    ...category,
    items: await Promise.all((category.items || []).map(async (item) => ({
      ...item,
      images: await Promise.all((item.images || []).map(resolveImageEntry))
    })))
  })));
  data.designImages = await Promise.all((data.designImages || []).map(async (images) =>
    Promise.all(images.map(resolveImageEntry))));
  return data;
}

function downloadFile(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function publishWebsiteData() {
  if (!updateDataFromInputs()) throw new Error("Your changes could not be saved before publishing.");
  setSaveState("saved", "Publish file prepared");
  const data = await getExportData();
  const source = `window.SNOWI_PUBLISHED_DATA = ${JSON.stringify(data).replace(/</g, "\\u003c")};\n`;
  downloadFile("public-site-data.js", source, "text/javascript");
  showToast("Publish file downloaded. Upload it to the Web folder with your site.");
}

async function restoreBackup(file) {
  const backup = JSON.parse(await file.text());
  const data = backup && backup.format === "snowi-admin-backup" ? backup.data : backup;
  if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("This file is not a valid website backup.");
  if (data.pricingCategories !== undefined && !Array.isArray(data.pricingCategories)) {
    throw new Error("The backup has an invalid pricing categories list.");
  }

  const restoredData = { ...defaultAdminData, ...data };
  restoredData.pricingCategories = normalizePricingCategories(restoredData.pricingCategories);
  restoredData.designImages = normalizeDesignImages(restoredData.designImages);
  restoredData.galleryImages = Array.isArray(restoredData.galleryImages) ? restoredData.galleryImages : [...defaultAdminData.galleryImages];
  restoredData.designImages = await Promise.all(restoredData.designImages.map(async (images) =>
    Promise.all(images.map(async (entry) => {
      if (typeof entry === "string" && entry.startsWith("data:")) return putImage(createImageId(), entry);
      return entry;
    }))));
  for (const category of restoredData.pricingCategories) {
    for (const item of category.items || []) {
      if (!Array.isArray(item.images)) continue;
      item.images = await Promise.all(item.images.map(async (entry) => {
        if (typeof entry === "string" && entry.startsWith("data:")) return putImage(createImageId(), entry);
        return entry;
      }));
    }
  }

  if (!setData(restoredData)) throw new Error("The backup could not be saved in this browser.");
  loadFields();
  buildPreview();
  setSaveState("saved", "Backup restored");
  showToast("Backup restored successfully.");
}

function attachEvents() {
  [
    { field: heroImageInput, key: "heroImage" },
    { field: aboutImageInput, key: "aboutImage" },
    ...galleryImageInputs.map((field, index) => ({ field, key: "galleryImages", index }))
  ].forEach(({ field, key, index }) => {
    if (!field) return;
    field.addEventListener("change", () => {
      const file = field.files && field.files[0];
      if (!file) return;
      prepareImage(file).then((imageData) => {
        const data = getData();
        if (Array.isArray(data[key])) {
          data[key][index] = imageData;
        } else {
          data[key] = imageData;
        }
        setData(data);
        buildPreview();
        field.value = "";
      }).catch(() => alert("This image could not be uploaded. Please try another image."));
    });
  });

  document.querySelectorAll(".clear-image-button").forEach((button) => {
    button.addEventListener("click", () => {
      const data = getData();
      const imageKey = button.dataset.imageKey;
      const imageIndex = Number(button.dataset.imageIndex);
      if (Array.isArray(data[imageKey])) data[imageKey][imageIndex] = "";
      else data[imageKey] = "";
      setData(data);
      buildPreview();
      showToast("Image removed.");
    });
  });

  const pricingImagesEditor = document.getElementById("pricing-images-editor");
  if (pricingImagesEditor) {
    pricingImagesEditor.addEventListener("change", (event) => {
      const input = event.target.closest(".pricing-item-image-input");
      if (!input) return;
      const files = Array.from(input.files || []);
      if (!files.length) return;
      const catIndex = Number(input.dataset.catIndex);
      const itemIndex = Number(input.dataset.itemIndex);
      Promise.allSettled(
        files.map((file) => prepareImage(file).then((dataUrl) => putImage(createImageId(), dataUrl)))
      ).then((results) => {
        const newIds = results.filter((result) => result.status === "fulfilled").map((result) => result.value);
        const failedCount = results.length - newIds.length;
        if (newIds.length) {
          const data = getData();
          const item = data.pricingCategories[catIndex].items[itemIndex];
          if (!Array.isArray(item.images)) item.images = [];
          item.images.push(...newIds);
          setData(data);
          syncPricingCategoriesField(data);
          buildPreview();
        }
        if (failedCount) {
          alert(`${failedCount} image(s) could not be uploaded. The rest were added.`);
        }
      });
    });

    pricingImagesEditor.addEventListener("click", (event) => {
      const removeButton = event.target.closest(".remove-pricing-image");
      if (!removeButton) return;
      const catIndex = Number(removeButton.dataset.catIndex);
      const itemIndex = Number(removeButton.dataset.itemIndex);
      const imageIndex = Number(removeButton.dataset.imageIndex);
      const data = getData();
      const [removedId] = data.pricingCategories[catIndex].items[itemIndex].images.splice(imageIndex, 1);
      setData(data);
      syncPricingCategoriesField(data);
      buildPreview();
      if (removedId) deleteImage(removedId).catch(() => {});
    });
  }

  saveButton.addEventListener("click", () => {
    try {
      if (updateDataFromInputs()) {
        setSaveState("saved", "All changes saved");
        showToast("Changes saved. Your storefront is updated.");
      } else {
        setSaveState("error", "Could not save changes");
      }
    } catch (error) {
      setSaveState("error", "Fix JSON before saving");
    }
  });

  resetButton.addEventListener("click", () => {
    if (!window.confirm("Reset all website content and pricing to the original defaults? Uploaded artwork references will be removed.")) return;
    localStorage.removeItem(stateKey);
    loadFields();
    buildPreview();
    setSaveState("saved", "Defaults restored");
    showToast("Website content reset to defaults.");
  });

  document.querySelectorAll("[data-admin-target]").forEach((button) => {
    button.addEventListener("click", () => {
      const search = document.getElementById("admin-search");
      search.value = "";
      document.getElementById("admin-search-empty").hidden = true;
      setActiveSection(button.dataset.adminTarget);
    });
  });

  document.getElementById("admin-search").addEventListener("input", (event) => filterAdminSections(event.target.value));
  document.getElementById("refresh-preview").addEventListener("click", () => {
    buildPreview();
    showToast("Preview refreshed from saved content.");
  });

  document.getElementById("publish-data").addEventListener("click", () => {
    publishWebsiteData().catch((error) => showToast(error.message || "The publish file could not be created."));
  });

  document.querySelectorAll("[data-preview-device]").forEach((button) => {
    button.addEventListener("click", () => {
      previewStage.dataset.device = button.dataset.previewDevice;
      document.querySelectorAll("[data-preview-device]").forEach((deviceButton) => {
        const isActive = deviceButton === button;
        deviceButton.classList.toggle("is-active", isActive);
        deviceButton.setAttribute("aria-pressed", String(isActive));
      });
      fitPreviewViewport();
    });
  });

  document.getElementById("expand-preview").addEventListener("click", (event) => {
    const button = event.currentTarget;
    const isExpanded = document.querySelector(".admin-preview").classList.toggle("is-expanded");
    button.textContent = isExpanded ? "Close" : "Expand";
    button.setAttribute("aria-pressed", String(isExpanded));
    requestAnimationFrame(fitPreviewViewport);
  });

  new ResizeObserver(fitPreviewViewport).observe(previewStage);

  document.getElementById("export-data").addEventListener("click", () => {
    downloadBackup().catch(() => showToast("Backup could not be created. Please try again."));
  });

  const importFile = document.getElementById("import-data-file");
  document.getElementById("import-data-button").addEventListener("click", () => importFile.click());
  importFile.addEventListener("change", async () => {
    const [file] = importFile.files || [];
    if (!file) return;
    if (!window.confirm("Restore this backup? It will replace the website content saved in this browser.")) {
      importFile.value = "";
      return;
    }
    try {
      await restoreBackup(file);
    } catch (error) {
      setSaveState("error", "Backup could not be restored");
      showToast(error.message || "This backup could not be restored.");
    }
    importFile.value = "";
  });

  document.querySelector(".admin-form").addEventListener("input", (event) => {
    if (!event.target.matches("input:not([type='file']), textarea")) return;
    setSaveState("unsaved", "Unsaved changes");
  });
}

function generateIndexHtml(data) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Snowi's Designs</title>
</head>
<body>
  <header>
    <nav class="navbar">
      <a href="index.html" class="nav-logo"><h2 class="logo-text">❄️Snowi<3</h2></a>
      <ul class="nav-menu">
        <li class="nav-item"><a href="#" class="nav-link">Home</a></li>
        <li class="nav-item"><a href="#about" class="nav-link">About me</a></li>
        <li class="nav-item"><a href="#pricing" class="nav-link">Design Services & Pricing</a></li>
        <li class="nav-item"><a href="#socials" class="nav-link">Follow me</a></li>
        <li class="nav-item"><a href="order.html" class="nav-link cart-link" aria-label="Order now" target="_blank" rel="noopener noreferrer"><span class="shopping-cart-icon" aria-hidden="true">🛒</span></a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section class="hero-section">
      <div class="section-content">
        <div class="hero-details">
          <h2 class="title">${data.heroTitle}</h2>
          <h3 class="subtitle">${data.heroSubtitle}</h3>
          <p class="description">${data.heroDescription}</p>
          <div class="buttons">
            <a href="order.html" class="button order-now">${data.heroButtonText}</a>
            <a href="#gallery" class="button contact-us">Gallery</a>
          </div>
        </div>
        <div class="hero-image-wrapper">
          ${data.heroImage ? `<img src="${data.heroImage}" alt="Hero image" class="hero-image" />` : ""}
        </div>
      </div>
    </section>

    <section class="about-section" id="about">
      <div class="section-content">
        <div class="about-image-wrapper">
          <img src="${data.aboutImage || "images/about-image.jpg"}" alt="About image" class="about-image" />
        </div>
        <div class="about-details">
          <h2 class="section-title">🤍Who am I?❄️</h2>
          <p class="text">I'm the owner of the Discord community and a digital artist creating custom graphics for Discord, YouTube, businesses, creators, and more. From emojis and stickers to logos and banners, I use Adobe After Effects, 3D software, and other creative tools to craft eye-catching, high-quality designs. 💫</p>
          <div class="social-link-list">
            <a href="#" class="social-link"><i class="fa-brands fa-facebook"></i></a>
            <a href="#" class="social-link"><i class="fa-brands fa-instagram"></i></a>
            <a href="#" class="social-link"><i class="fa-brands fa-x-twitter"></i></a>
          </div>
        </div>
      </div>
    </section>

    <section class="pricing-section" id="pricing">
      <div class="section-content pricing-layout">
        <div class="pricing-panel pricing-pairs-panel">
          <p class="pricing-intro">Choose the package that fits your online presence. Each service below is shown with the price that belongs to it, so you can compare value quickly.</p>
          <div class="pricing-pairs">
            ${data.packages.map(pkg => `
            <article class="pricing-pair">
              <div class="service-card">
                <div class="service-icon">✨</div>
                <div>
                  <h3 class="service-title">${pkg.title}</h3>
                  <p class="service-text">${pkg.description}</p>
                </div>
              </div>
              <div class="pricing-card">
                <h3 class="price-title">${pkg.title}</h3>
                <p class="price">${pkg.price}</p>
                <p class="price-desc">${pkg.description}</p>
              </div>
            </article>
            `).join("")}
          </div>
        </div>
      </div>
    </section>

    <section class="faq-section" id="faq">
      <div class="section-content">
        <h2 class="section-title">Frequently Asked Questions</h2>
        <div class="faq-list">
          ${data.faqs.map(faq => `
          <details class="faq-item">
            <summary>${faq.question}</summary>
            <p class="text">${faq.answer}</p>
          </details>
          `).join("")}
        </div>
      </div>
    </section>
  </main>
</body>
</html>`;
}

buildPreview();
loadFields();
attachEvents();
fitPreviewViewport();
