const revealSelector = [
  'main > section',
  '.about-image-wrapper',
  '.about-details',
  '.gallery-card',
  '.work-card',
  '.pricing-card',
  '.menu-item',
  '.faq-item',
  '.contact-info',
  '.contact-form',
  'footer',
  '.page-nav',
  '.gallery-page-grid > article',
  '.design-services-page-grid > article'
].join(', ');

const revealElements = Array.from(document.querySelectorAll(revealSelector));

if (!revealElements.length) {
  // No reveal elements on this page.
}

revealElements.forEach((element, index) => {
  element.classList.add('reveal-on-scroll');
  element.style.transitionDelay = `${index * 35}ms`;
});

const revealObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.15 }
);

revealElements.forEach((element) => revealObserver.observe(element));
