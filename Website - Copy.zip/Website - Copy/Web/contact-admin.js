(() => {
  const config = window.SNOWI_CONTACT_CONFIG || {};
  const configured = typeof config.supabaseUrl === "string"
    && config.supabaseUrl.startsWith("https://")
    && typeof config.supabaseAnonKey === "string"
    && config.supabaseAnonKey
    && !config.supabaseAnonKey.startsWith("PASTE_");
  const loginForm = document.getElementById("contact-admin-login-form");
  const status = document.getElementById("contact-admin-status");
  const workspace = document.getElementById("contact-admin-workspace");
  const commissionRequestList = document.getElementById("commission-request-list");
  const signOutButton = document.getElementById("contact-admin-sign-out");
  const submissionList = document.getElementById("contact-admin-workspace");

  function setStatus(message, isError = false) {
    status.textContent = message;
    status.classList.toggle("is-error", isError);
  }

  function setSignedIn(isSignedIn) {
    loginForm.hidden = isSignedIn;
    signOutButton.hidden = !isSignedIn;
    workspace.hidden = !isSignedIn;
    commissionRequestList.hidden = !isSignedIn;
  }

  if (!configured || !window.supabase) {
    loginForm.querySelector('[type="submit"]').disabled = true;
    setStatus("Connect Supabase in contact-config.js to enable customer messages and commission requests.", true);
    return;
  }

  const client = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey, {
    auth: {
      storageKey: "snowi-contact-admin-auth",
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false
    }
  });
  let adminUser = null;
  let realtimeChannel = null;

  function formatPhoneForSms(phone) {
    return phone.replace(/[^\d+]/g, "");
  }

  function createSubmissionCard(submission) {
    const card = document.createElement("article");
    card.className = "customer-submission";

    const heading = document.createElement("div");
    heading.className = "customer-submission-heading";
    const name = document.createElement("h3");
    name.textContent = submission.customer_name;
    const badge = document.createElement("span");
    badge.className = `customer-submission-status is-${submission.status}`;
    badge.textContent = submission.status === "replied" ? "Replied" : "New";
    heading.append(name, badge);

    const phone = document.createElement("a");
    phone.className = "customer-submission-phone";
    phone.href = `tel:${formatPhoneForSms(submission.phone)}`;
    phone.textContent = submission.phone;

    const message = document.createElement("p");
    message.className = "customer-submission-message";
    message.textContent = submission.message;

    const footer = document.createElement("div");
    footer.className = "customer-submission-footer";
    const time = document.createElement("time");
    time.dateTime = submission.created_at;
    time.textContent = new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short"
    }).format(new Date(submission.created_at));
    const actions = document.createElement("div");
    actions.className = "customer-submission-actions";
    const replyLink = document.createElement("a");
    replyLink.className = "admin-button admin-button-primary";
    replyLink.href = `sms:${formatPhoneForSms(submission.phone)}`;
    replyLink.textContent = "Reply by SMS";
    replyLink.setAttribute("aria-label", `Reply to ${submission.customer_name} by text message`);
    actions.appendChild(replyLink);

    if (submission.status !== "replied") {
      const markReplied = document.createElement("button");
      markReplied.type = "button";
      markReplied.className = "admin-button mark-customer-replied";
      markReplied.textContent = "Mark replied";
      markReplied.addEventListener("click", () => markAsReplied(submission.id, markReplied));
      actions.appendChild(markReplied);
    }

    footer.append(time, actions);
    card.append(heading, phone, message, footer);
    return card;
  }

  function createCommissionRequestCard(request) {
    const card = document.createElement("article");
    card.className = "customer-submission";

    const heading = document.createElement("div");
    heading.className = "customer-submission-heading";
    const name = document.createElement("h3");
    name.textContent = request.customer_name;
    const badge = document.createElement("span");
    badge.className = `customer-submission-status is-${request.status}`;
    badge.textContent = request.status === "replied" ? "Replied" : "New";
    heading.append(name, badge);

    const email = document.createElement("a");
    email.className = "commission-request-email";
    email.href = `mailto:${request.customer_email}`;
    email.textContent = request.customer_email;

    const details = document.createElement("p");
    details.className = "commission-request-meta";
    details.textContent = `${request.service_category} · ${request.service_name} · ${request.listed_price} · Quantity ${request.quantity} · ${request.preferred_timing}`;

    const brief = document.createElement("p");
    brief.className = "customer-submission-message";
    brief.textContent = request.creative_brief;

    const files = document.createElement("p");
    files.className = "commission-request-files";
    const fileNames = Array.isArray(request.reference_files) ? request.reference_files : [];
    files.textContent = fileNames.length
      ? `Reference files to request by email: ${fileNames.join(", ")}`
      : "No reference files listed.";

    const footer = document.createElement("div");
    footer.className = "customer-submission-footer";
    const time = document.createElement("time");
    time.dateTime = request.created_at;
    time.textContent = new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short"
    }).format(new Date(request.created_at));
    const actions = document.createElement("div");
    actions.className = "customer-submission-actions";
    const replyLink = document.createElement("a");
    replyLink.className = "admin-button admin-button-primary";
    replyLink.href = `mailto:${request.customer_email}`;
    replyLink.textContent = "Reply by email";
    replyLink.setAttribute("aria-label", `Reply to ${request.customer_name} by email`);
    actions.appendChild(replyLink);

    if (request.status !== "replied") {
      const markReplied = document.createElement("button");
      markReplied.type = "button";
      markReplied.className = "admin-button mark-customer-replied";
      markReplied.textContent = "Mark replied";
      markReplied.addEventListener("click", () => markRequestReplied(request.id, markReplied));
      actions.appendChild(markReplied);
    }

    footer.append(time, actions);
    card.append(heading, email, details, brief, files, footer);
    return card;
  }

  async function loadSubmissions() {
    const { data, error } = await client.from("contact_submissions")
      .select("id, customer_name, phone, message, status, created_at")
      .order("created_at", { ascending: false });
    if (error) throw error;
    submissionList.replaceChildren();
    if (!data.length) {
      const empty = document.createElement("p");
      empty.className = "customer-submissions-empty";
      empty.textContent = "No customer messages yet.";
      submissionList.appendChild(empty);
      return;
    }
    data.forEach((submission) => submissionList.appendChild(createSubmissionCard(submission)));
  }

  async function loadCommissionRequests() {
    const requests = [];
    const pageSize = 500;
    for (let offset = 0; ; offset += pageSize) {
      const { data, error } = await client.from("commission_requests")
        .select("id, customer_name, customer_email, service_category, service_name, listed_price, quantity, preferred_timing, creative_brief, reference_files, status, created_at")
        .order("created_at", { ascending: false })
        .range(offset, offset + pageSize - 1);
      if (error) throw error;
      requests.push(...data);
      if (data.length < pageSize) break;
    }
    commissionRequestList.replaceChildren();
    if (!requests.length) {
      const empty = document.createElement("p");
      empty.className = "customer-submissions-empty";
      empty.textContent = "No commission requests yet.";
      commissionRequestList.appendChild(empty);
      return;
    }
    requests.forEach((request) => commissionRequestList.appendChild(createCommissionRequestCard(request)));
  }

  async function markAsReplied(submissionId, button) {
    button.disabled = true;
    const { error } = await client.from("contact_submissions")
      .update({ status: "replied" })
      .eq("id", submissionId);
    button.disabled = false;
    if (error) {
      setStatus("Could not update this message. Please try again.", true);
      return;
    }
    setStatus("Message marked as replied.");
    await loadSubmissions();
  }

  async function startInbox(user) {
    const { data: adminRecord, error: adminError } = await client.from("contact_admins")
      .select("user_id")
      .eq("user_id", user.id)
      .maybeSingle();
    if (adminError || !adminRecord) {
      await client.auth.signOut();
      adminUser = null;
      setSignedIn(false);
      setStatus("This account is not authorized to view customer messages.", true);
      return;
    }

    adminUser = user;
    setSignedIn(true);
    setStatus("Signed in. Customer messages and commission requests will appear here.");
    await Promise.all([loadSubmissions(), loadCommissionRequests()]);
    if (realtimeChannel) client.removeChannel(realtimeChannel);
    realtimeChannel = client.channel("customer-submissions-and-requests")
      .on("postgres_changes", { event: "*", schema: "public", table: "contact_submissions" }, () => {
        loadSubmissions().catch(() => setStatus("Could not refresh customer messages.", true));
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "commission_requests" }, () => {
        loadCommissionRequests().catch(() => setStatus("Could not refresh commission requests.", true));
      })
      .subscribe();
  }

  async function markRequestReplied(requestId, button) {
    button.disabled = true;
    const { error } = await client.from("commission_requests")
      .update({ status: "replied" })
      .eq("id", requestId);
    button.disabled = false;
    if (error) {
      setStatus("Could not update this request. Please try again.", true);
      return;
    }
    setStatus("Request marked as replied.");
    await loadCommissionRequests();
  }

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!loginForm.reportValidity()) return;
    const submitButton = loginForm.querySelector('[type="submit"]');
    submitButton.disabled = true;
    setStatus("Signing in…");
    const formData = new FormData(loginForm);
    const { data, error } = await client.auth.signInWithPassword({
      email: String(formData.get("email") || ""),
      password: String(formData.get("password") || "")
    });
    submitButton.disabled = false;
    if (error) {
      setStatus("Sign-in failed. Check your email and password.", true);
      return;
    }
    try {
      await startInbox(data.user);
      loginForm.reset();
    } catch (inboxError) {
      console.error("Customer messages and commission requests could not be loaded.", inboxError);
      setStatus("Could not load inbox items. Check database setup and admin access.", true);
    }
  });

  signOutButton.addEventListener("click", async () => {
    if (realtimeChannel) client.removeChannel(realtimeChannel);
    realtimeChannel = null;
    adminUser = null;
    await client.auth.signOut();
    setSignedIn(false);
    setStatus("You’re signed out.");
    submissionList.replaceChildren();
    commissionRequestList.replaceChildren();
  });

  client.auth.getSession().then(({ data, error }) => {
    if (error) {
      setStatus("Could not restore your sign-in. Please sign in again.", true);
      return;
    }
    if (data.session?.user) {
      startInbox(data.session.user).catch(() => setStatus("Could not load inbox items.", true));
    }
  });
})();
