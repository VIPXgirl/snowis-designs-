// Stores uploaded photo data in IndexedDB (much larger quota than localStorage) so many photos per service fit.
const IMAGE_DB_NAME = "snowiImageStore";
const IMAGE_STORE_NAME = "images";

let imageDbPromise = null;

function openImageDb() {
  if (imageDbPromise) return imageDbPromise;
  imageDbPromise = new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error("IndexedDB is not available in this browser."));
      return;
    }
    const request = indexedDB.open(IMAGE_DB_NAME, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(IMAGE_STORE_NAME)) {
        request.result.createObjectStore(IMAGE_STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  return imageDbPromise;
}

function createImageId() {
  return `img-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

async function putImage(id, dataUrl) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IMAGE_STORE_NAME, "readwrite");
    tx.objectStore(IMAGE_STORE_NAME).put(dataUrl, id);
    tx.oncomplete = () => resolve(id);
    tx.onerror = () => reject(tx.error);
  });
}

async function getImage(id) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IMAGE_STORE_NAME, "readonly");
    const request = tx.objectStore(IMAGE_STORE_NAME).get(id);
    request.onsuccess = () => resolve(request.result || "");
    request.onerror = () => reject(request.error);
  });
}

async function getImages(ids) {
  const results = await Promise.all((ids || []).map((id) => getImage(id).catch(() => "")));
  return results.filter(Boolean);
}

async function deleteImage(id) {
  const db = await openImageDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(IMAGE_STORE_NAME, "readwrite");
    tx.objectStore(IMAGE_STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// Resolves a mix of legacy inline data URLs (saved before IndexedDB was used) and image-store IDs.
async function resolveImageEntry(entry) {
  if (typeof entry !== "string" || !entry) return "";
  if (entry.startsWith("data:")) return entry;
  return getImage(entry).catch(() => "");
}

async function resolveImageEntries(entries) {
  const results = await Promise.all((entries || []).map(resolveImageEntry));
  return results.filter(Boolean);
}
